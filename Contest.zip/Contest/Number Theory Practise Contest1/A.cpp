#include<bits/stdc++.h>
using namespace std;
#define pii pair<int,int>
#define pb push_back
#define ll long long
#define Max 50005
int ara[Max];
void seive()
{
    for(int i=4;i<=Max;i+=2) ara[i]=1;
    int sq = sqrt(Max);
    for(int i=3;i<=sq;i+=2){
        if(ara[i]){
            for(int j=i*i;j<=Max;j+=2*i){
                ara[j] = 1;
            }
        }
    }

}
ll solve(int a,int p){

    ll ans = 1;
   // cout<<a<<' '<<p<<endl;
    for(int i=1;i<=p;i++){
        ans*=a;
    }
    return ans;
}
int main()
{
    memset(ara,0,sizeof(ara));
    seive();
    int prime[Max];
    int c=1;
    prime[0]=2;
    for(int i=3;i<=Max;i+=2) if(!ara[i]) prime[c++] = i;
    int n,m;
    char ch;
    while(scanf("%d",&n)!=EOF){

        vector<pii>vc;
        int N=n;

        

        if(n<0){
            vc.pb(pii(-1,1));
            n=n*(-1);
        }
        //cout<<n<<endl;
        int sq = sqrt(n) + 1;

        for(int i=0;prime[i]<=sq;i++){
            if(!(n%prime[i])){
                int cnt=0;
                while(!(n%prime[i])){
                    n/=prime[i];
                    cnt++;
                }
                //cout<<i<<' '<<cnt<<endl;
                vc.pb(pii(prime[i],cnt));
                //ans*=solve(cnt,prime[i]);
            }
        }

        if(n>1){
          vc.pb(pii(n,1));
        }

        for(int i=0;i<vc.size();i++){
            
            if(i==0){
                if(vc[i].second>1){
                    printf("%d^%d",vc[i].first,vc[i].second);
                }
                else{
                    printf("%d",vc[i].first);
                }
            }

            else{
                if(vc[i].second>1){
                    printf(" %d^%d",vc[i].first,vc[i].second);
                }
                else{
                    printf(" %d",vc[i].first);
                }
            }

        }
        cout<<endl;

    }
    return 0;
}