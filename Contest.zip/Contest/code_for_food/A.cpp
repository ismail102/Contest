#include<bits/stdc++.h>
using namespace std;
int main()
{
    string str;
    int n,K;
    while(cin>>n>>K)
    {
        cin>>str;
        int len = str.size();
        int L=0,W=0;
        for(int i=0;i<len;i++){

            if(str[i]=='L'){
                L++;
            }
            else if(str[i]=='W') W++;
        }

        if(abs(W-L)==K) puts("NO");
        else{
            
            if(W<=L){
                for(int i=0;i<len;i++){
                    if(str[i]=='?'){
                        if(abs(W-L)<K){
                            str[i]='L';
                            L++;
                        }
                        else{
                            if(abs(W-L)>K){
                                str[i]='w';
                                W++;
                            }
                            else str[i]='D';
                        }
                    }
                }
            }
            else{

                for(int i=0;i<len;i++){
                    if(str[i]=='?'){
                        if(abs(W-L)<K){
                            str[i]='W';
                            W++;
                        }
                        else{
                            if(abs(W-L)>K){
                                str[i]='L';
                                L++;
                            }
                            else str[i]='D';
                        }
                    }
                }
            }
            
            if(abs(W-L)!=K) puts("NO");
            else cout<<str<<endl;
        }

    }
    return 0;

}
