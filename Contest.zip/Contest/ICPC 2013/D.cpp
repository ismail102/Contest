#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll m = 10000000000007;

unsigned long long f[10005];
unsigned long long bigmod ( unsigned long long a, unsigned long long p)
{
    unsigned long long res = 1LL;
    unsigned long long x = a;
     cout<<a<<' '<<p<<endl;
    while ( p )
    {
        if ( p & 1LL )
        {
            res = ( (res%10000000000007) * (x%10000000000007) ) % 10000000000007;
        }
        x = ((x%10000000000007) * (x%10000000000007 )) % 10000000000007;
        p = p/(ll)2;
    }
    
    cout<<"bigmod = "<<res<<endl;
    return res;
}

void fact()
{
    f[0]=1;
    for(int i=1;i<=10000;i++){
        f[i] = (f[i-1]%10000000000007 * i%10000000000007)%10000000000007;
    }
    for(int i=1;i<=10;i++) cout<<f[i]<<' ';
    cout<<endl;
}
int main()
{
    fact();

    int L,M,N;
    while(cin>>L>>M>>N)
    {
        unsigned ll ans = 0;
        for(int i=M;i<=N;i++){
            cout<<f[L*L]<<' '<<f[L*L-i]<<endl;
            unsigned ll tt = bigmod(f[L*L-i],10000000000007-2);
            cout<<tt<<endl;
            ans += (f[L*L])*tt;
            ans%=10000000000007;
        }
        cout<<ans<<endl;
    }

return 0;

}