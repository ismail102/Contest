#include<bits/stdc++.h>
using namespace std;
int ch[50];
int main()
{
    string str;
    int t,cas=1;
    scanf("%d",&t);
    while(t--){
        string st,temp;
        cin>>str;
        int cnt=0;
        int len = str.size();
        for(int i=0;i<len;i++){
            temp="";
            for(int j=1;j<=26;j++) ch[j]=0;
            
            for(int j=i;j<len;j++){

                temp+=str[j];
                int c=0;
                
                ch[str[j]-'a' + 1]++;
                for(int k=1;k<=26;k++){
                    if((ch[k]%2)){
                        c++;
                    }
                    if(c>1){
                        break;
                    }
                }
                if(c<=1) cnt++;

            }
        }
        printf("Case %d: %d\n",cas++,cnt);

      
    }
    return 0;
}