#include<bits/stdc++.h>
using namespace std;
int main()
{
    double L,H,W;
    int n;
    while(cin>>n){
        if(n==0) break;

         double vol,mxvol=0,mx=0;
        for(int i=0;i<n;i++){

            cin>>L>>W>>H;
              vol = L*W*H;
            if(mx<H){
                mx = H;
                mxvol = vol;
            }
            else if(mx==H){
                if(mxvol<vol) mxvol = vol;
            }
        }
        cout<<mxvol<<endl;

    }
    return 0;
}