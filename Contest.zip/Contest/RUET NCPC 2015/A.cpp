#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define Max 100005;
int ara[Max];
int main()
{
    int n,m;
    

    return 0;
}