#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define Max 100005;
int ara[10000];
int main()
{
    int n,m;
    int t,cas=1;
    scanf("%d",&t);
    while(t--){
        int x;
        scanf("%d%d",&n,&m);
        int mn=0;
        for(int i=0;i<n;i++) scanf("%d",&ara[i]);
        for(int i=0;i<n;i++){
            scanf("%d",&x);
            int xx=min(x,ara[i]);
            ara[i]-=xx;
            mn+=xx;
        }
        //cout<<mn<<endl;
        int y=0;
        for(int i=0;i<n;i++){
            y+=ara[i];
        }
        
        if(mn<=m and y==0)printf("Case %d: Yes\n",cas++);
        else printf("Case %d: No\n",cas++);
    }   

    return 0;
}