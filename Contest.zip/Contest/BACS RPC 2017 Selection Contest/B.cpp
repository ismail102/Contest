#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define mem(a,b) memset(a,b,sizeof(a))
int ara[5005],temp[1005];
int dp[5005][5005];
int n;
int solve(int i,int k)
{
    if(i>=n) return 0;

    if(dp[i][k]!=-1) return dp[i][k];

    if(ara[i]>=0) dp[i][k] = ara[i] + solve(i+1,k);

    else{
        int p=0,q=0;
        if(k!=0){
            p = solve(i+1,k-1);
        }
            q = ara[i] + solve(i+1,k);
        dp[i][k] = max(p,q);
    }

    return dp[i][k];
}
int main()
{
    int t,i,cas=1;
    scanf("%d",&t);
    while(t--)
    {
        int k;
        memset(dp,-1,sizeof(dp));
        scanf("%d%d",&n,&k);
        int cnt=0,mn=10000000007;
        for(int i=0;i<n;i++){
            scanf("%d",&ara[i]);
            if(ara[i]<0) cnt++;
            mn = min(mn,abs(ara[i]));
        }

        if(cnt==n and k==0){
            printf("Case %d: %d\n",cas++,-1*mn);
            continue;
        }

        int ans = solve(0,k);
        int res = 0;
        for(int i=0;i<n;i++){
            res =  max(res,dp[i][k]);
        }
        printf("Case %d: %d\n",cas++,res);

    }
    return 0;
}
