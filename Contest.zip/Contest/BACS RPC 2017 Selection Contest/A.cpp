#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pii pair<int,int>
#define mem(a,b) memset(a,b,sizeof(a))
int ara[1005],temp[1005];
int main()
{
    int t,i;
    scanf("%d",&t);
    while(t--)
    {
        int n;
        scanf("%d",&n);
        for(i=0;i<n;i++){
            scanf("%d",&ara[i]);
            temp[i] = ara[i];
        }
       // sort(temp,temp+n);
       for( i=1;i<n;i++){
            if(ara[i]!=ara[i-1]) break;
        }
        if(i==n){
            puts("neutral");
            continue;
        }

        for( i=1;i<n;i++){
            if(ara[i]>ara[i-1]) break;
        }
        if(i==n)
        {
            puts("allBadDays");
            continue;
        }

        for(i=1;i<n;i++){
            if(ara[i]<ara[i-1]) break;
        }
        if(i==n)
        {
            puts("allGoodDays");
            continue;
        }


        int cnt=0,ans=0;
        int tt;
        vector<int>vc;
        for(i=1;i<n;i++){

            if(i+1<n and ara[i]>ara[i-1] and ara[i]>ara[i+1]){
                cnt++;
                vc.push_back(i);
            }
        }

        if(cnt<2){
            puts("none");
        }
        else{

            for(int i=1;i<vc.size();i++){
                ans=max(ans,vc[i] - vc[i-1] - 1);
            }
            printf("%d\n",ans);
        }





    }
}
