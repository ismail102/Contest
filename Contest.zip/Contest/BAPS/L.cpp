#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
int main()
{
    int n;
    while(cin>>n)
    {
        if(n==0) return  0;

        ull a=1,b=2;
        if(n==1) cout<<a<<endl;
        else if(n==2) cout<<b<<endl;
        else{
            ull c;
            for(int i=3;i<=n;i++){
                 c=a+b;
                 a=b;
                 b=c;
            }
            cout<<c<<endl;
        }
    }

}